﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AI_MasterControl.Element
{
    public class ElementPoint:Element
    {
        public ElementPoint(Int32 type,Int32 x,Int32 y,ElementColor color):base(type,color,x,y)
        {
        }
    }
}
